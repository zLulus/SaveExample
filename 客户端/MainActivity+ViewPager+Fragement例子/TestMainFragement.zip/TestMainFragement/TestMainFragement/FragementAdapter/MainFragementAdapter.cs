using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.App;
using Android.Support.V4.View;
using Android.Views;
using Android.Widget;
using MainActivity.Fragement;
using Fragment = Android.Support.V4.App.Fragment;
using FragmentManager = Android.Support.V4.App.FragmentManager;
namespace MainActivity.FragementAdapter
{
   public   class MainFragementAdapter :Android.Support.V4.App.FragmentPagerAdapter
    {
        private List<Fragment> _fragmentList = new List<Fragment>();
        public MainFragementAdapter(FragmentManager fm)
            : base(fm) {}

        public override int Count
        {
            get { return _fragmentList.Count; }
        }

        public override Fragment GetItem(int position)
        {
            return _fragmentList[position];
        }

        public void AddFragment(MainFragment fragment)
        {
            _fragmentList.Add(fragment);
        }

        public void AddFragmentView(Func<LayoutInflater, ViewGroup, Bundle, View> view)
        {
            _fragmentList.Add(new MainFragment(view));
        }
    }
  

}