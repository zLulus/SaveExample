﻿using System;
using Android.App;
using Android.Content;
using Android.Graphics;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Support.V4.App;
using Android.Support.V4.View;
using Android.Support.V7.App;
using MainActivity.Fragement;
using FragmentManager = Android.Support.V4.App.FragmentManager;
using MainActivity.FragementAdapter;
using FragmentTransaction = Android.Support.V4.App.FragmentTransaction;

namespace TestMainFragement
{
    [Activity(Label = "TestMainFragement", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : FragmentActivity, Android.Views.View.IOnClickListener, Android.Support.V4.View.ViewPager.IOnPageChangeListener
    {
    
        //定义一个ViewPager容器
        private ViewPager mPager;
        private MainFragementAdapter mAdapter;
        //下面每个Layout对象
        private RelativeLayout weixin_layout;
        private RelativeLayout tongxunlu_layout;
        private RelativeLayout faxian_layout;
        private RelativeLayout me_layout;
        //依次获得ImageView与TextView
        private ImageView weixin_img;
        private ImageView tongxunlu_img;
        private ImageView faxian_img;
        private ImageView me_img;
        private TextView weixin_txt;
        private TextView tongxunlu_txt;
        private TextView faxian_txt;
        private TextView me_txt;
        //定义FragmentManager对象
        private FragmentManager fManager;
        private Color lightBlue = Android.Graphics.Color.Rgb(33, 150, 243);
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);
            fManager = this.SupportFragmentManager;
            initViewPager();
            initViews();
            initState();
        }

        private void initViewPager()
        {
            mAdapter = new MainFragementAdapter(fManager);
            mAdapter.AddFragment(new FragmentMap());
            mAdapter.AddFragment(new FragmentFriend());
            mAdapter.AddFragment(new FragmentScenic());
            mAdapter.AddFragment(new FragmentSetting());
        }

        private void initViews()
        {
            mPager = FindViewById<ViewPager>(Resource.Id.vPager);
            weixin_layout = FindViewById<RelativeLayout>(Resource.Id.weixin_layout);
            tongxunlu_layout = FindViewById<RelativeLayout>(Resource.Id.tongxunlu_layout);
            faxian_layout = FindViewById<RelativeLayout>(Resource.Id.faxian_layout);
            me_layout = FindViewById<RelativeLayout>(Resource.Id.me_layout);
            weixin_img = FindViewById<ImageView>(Resource.Id.weixin_img);
            tongxunlu_img = FindViewById<ImageView>(Resource.Id.tongxunlu_img);
            faxian_img = FindViewById<ImageView>(Resource.Id.faxian_img);
            me_img = FindViewById<ImageView>(Resource.Id.me_img);
            weixin_txt = FindViewById<TextView>(Resource.Id.weixin_txt);
            tongxunlu_txt = FindViewById<TextView>(Resource.Id.tongxunlu_txt);
            faxian_txt = FindViewById<TextView>(Resource.Id.faxian_txt);
            me_txt = FindViewById<TextView>(Resource.Id.me_txt);
            mPager.Adapter = mAdapter;
            mPager.OffscreenPageLimit = 3;//缓存当前界面每一侧的界面数,设置ViewPager的缓存界面数。
            mPager.SetOnPageChangeListener(this);
            weixin_layout.SetOnClickListener(this);
            tongxunlu_layout.SetOnClickListener(this);
            faxian_layout.SetOnClickListener(this);
            me_layout.SetOnClickListener(this);
        }
	




        //定义一个设置初始状态的方法
        private void initState()
        {
          
            weixin_txt.SetTextColor(lightBlue);
            mPager.CurrentItem = 0;
        }

        public void OnClick(View v)
        {
            clearChioce();
            iconChange(v.Id);
        }

        public void OnPageScrollStateChanged(int state)
        {
            if (state == 2)
            {
                int i = mPager.CurrentItem;
                clearChioce();
                iconChange(i);
            
            }
        }

        public void OnPageScrolled(int position, float positionOffset, int positionOffsetPixels)
        {
        }

        public void OnPageSelected(int position)
        {
        }

        //建立一个清空选中状态的方法
        public void clearChioce()
        {
            weixin_img.SetImageResource(Resource.Drawable.ahk);
            weixin_txt.SetTextColor(Android.Graphics.Color.Gray);
            tongxunlu_img.SetImageResource(Resource.Drawable.ahi);
            tongxunlu_txt.SetTextColor(Android.Graphics.Color.Gray);
            faxian_img.SetImageResource(Resource.Drawable.ahm);
            faxian_txt.SetTextColor(Android.Graphics.Color.Gray);
            me_img.SetImageResource(Resource.Drawable.aho);
            me_txt.SetTextColor(Android.Graphics.Color.Gray);
        }

        //定义一个底部导航栏图标变化的方法
        public void iconChange(int num)
        {
            switch (num)
            {
                case Resource.Id.weixin_layout:
                case 0:
                    weixin_img.SetImageResource(Resource.Drawable.ahj);
                    weixin_txt.SetTextColor(lightBlue);
                    mPager.CurrentItem = 0;
                    break;
                case Resource.Id.tongxunlu_layout:
                case 1:
                    tongxunlu_img.SetImageResource(Resource.Drawable.ahh);
                    tongxunlu_txt.SetTextColor(lightBlue);
                    mPager.CurrentItem = 1;
                    break;
                case Resource.Id.faxian_layout:
                case 2:
                    faxian_img.SetImageResource(Resource.Drawable.ahl);
                    faxian_txt.SetTextColor(lightBlue);
                    mPager.CurrentItem = 2;
                    break;
                case Resource.Id.me_layout:
                case 3:
                    me_img.SetImageResource(Resource.Drawable.ahn);
                    me_txt.SetTextColor(lightBlue);
                    mPager.CurrentItem = 3;
                    break;
            }
        }














    }
}

