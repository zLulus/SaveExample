﻿// Copyright (c) 2007-2016 Thong Nguyen (tumtumtum@gmail.com)
namespace Shaolinq.Sqlite
{
	public static class SqliteErrorCodes
	{
		public const int SqliteConstraint = 19;
	}
}