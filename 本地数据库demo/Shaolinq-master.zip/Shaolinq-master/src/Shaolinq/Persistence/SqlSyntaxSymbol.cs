﻿// Copyright (c) 2007-2016 Thong Nguyen (tumtumtum@gmail.com)
namespace Shaolinq.Persistence
{
	public enum SqlSyntaxSymbol
	{
		Null,
		Like,
		StringQuote,
		IdentifierQuote,
		ParameterPrefix,
		AutoIncrement
	}
}
